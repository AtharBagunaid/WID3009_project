package pacman.controllers.examples;

import java.util.ArrayList;
import java.util.Random;
import pacman.controllers.Controller;
import pacman.game.Game;

import static pacman.game.Constants.*;

/*
 * Pac-Man controller as part of the starter package - simply upload this file as a zip called
 * MyPacMan.zip and you will be entered into the rankings - as simple as that! Feel free to modify 
 * it or to start from scratch, using the classes supplied with the original software. Best of luck!
 * 
 * This controller utilises 3 tactics, in order of importance:
 * 1. Get away from any non-edible ghost that is in close proximity
 * 2. Go after the nearest edible ghost
 * 3. Go to the nearest pill/power pill
 */
public class StarterPacMan extends Controller<MOVE>
{	
	private static final int MIN_DISTANCE=20;	//if a ghost is this close, run away
//	NearestPillPacMan pill = new NearestPillPacMan();
              
//=======================================================================================       
	public MOVE getMove(Game game,long timeDue)
	{			
		int current=game.getPacmanCurrentNodeIndex();
                
                // from strategy 3 creating the pills arrays:
                //get all active pills
		int[] activePills=game.getActivePillsIndices();
		
		//get all active power pills
		int[] activePowerPills=game.getActivePowerPillsIndices();
		
		//create a target array that includes all ACTIVE pills and power pills
		int[] targetNodeIndices=new int[activePills.length+activePowerPills.length];
		
		for(int i=0;i<activePills.length;i++)
			targetNodeIndices[i]=activePills[i];
                
		for(int i=0;i<activePowerPills.length;i++)
			targetNodeIndices[activePills.length+i]=activePowerPills[i];	
                
               
    //=====================================================================================================	
		//Strategy 1: if any non-edible ghost is too close (less than MIN_DISTANCE), run away
                int pillDistance = game.getShortestPathDistance(current, game.getClosestNodeIndexFromNodeIndex(game.getPacmanCurrentNodeIndex(),targetNodeIndices,DM.PATH));
		for(GHOST ghost : GHOST.values())
			if(game.getGhostEdibleTime(ghost)==0 && game.getGhostLairTime(ghost)==0)
				if(game.getShortestPathDistance(current,game.getGhostCurrentNodeIndex(ghost))<=MIN_DISTANCE && game.getShortestPathDistance(current, game.getGhostCurrentNodeIndex(ghost)) <= pillDistance)
                                     return game.getNextMoveAwayFromTarget(game.getPacmanCurrentNodeIndex(),game.getGhostCurrentNodeIndex(ghost),DM.PATH);
                                        
//=======================================================================================
		//Strategy 2: find the nearest edible ghost and go after them 
//		int minDistance=game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(),game.getClosestNodeIndexFromNodeIndex(game.getPacmanCurrentNodeIndex(),targetNodeIndices,DM.PATH));
		GHOST minGhost=null;	
                int minDistance = Integer.MAX_VALUE;		
		for(GHOST ghost : GHOST.values())
                {
                    int distance=game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(),game.getGhostCurrentNodeIndex(ghost));

			if(game.getGhostEdibleTime(ghost)>0)
			{
                            if(distance < minDistance)
                            {
                                minDistance=distance;
                                minGhost=ghost;
                            }    	
			}
                }
                
		if(minGhost!=null && game.getGhostEdibleTime(minGhost)>=10)	//we found an edible ghost
                    return game.getNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),game.getGhostCurrentNodeIndex(minGhost),DM.PATH);
	
//=======================================================================================	
		//Strategy 3: go after the pills and power pills         
         
                // Modefied strategy3:
                int currentNodeIndex=game.getPacmanCurrentNodeIndex();		
			
		// after filling the pills arrays execute strategy 3 collecting the pills
		//return the next direction once the closest target has been identified
                int powerPillDistance =0;
                // To calculate the nearst distance of powerPills as long as they exit to avoid indexing error from calculating the distance after there is not more powerPills 
                if(activePowerPills.length > 0)
                    powerPillDistance = game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getClosestNodeIndexFromNodeIndex(game.getPacmanCurrentNodeIndex(), activePowerPills, DM.PATH));
//               
                if(activePowerPills.length > 0 && powerPillDistance <=40)
                    return game.getNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),game.getClosestNodeIndexFromNodeIndex(game.getPacmanCurrentNodeIndex(),activePowerPills,DM.PATH),DM.PATH);
               
           	else  
                    return game.getNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),game.getClosestNodeIndexFromNodeIndex(game.getPacmanCurrentNodeIndex(),targetNodeIndices,DM.PATH),DM.PATH);	
              
                
//====================================================================================================================================
//		// Original Strategy 3
//              int[] pills=game.getPillIndices();
//		int[] powerPills=game.getPowerPillIndices();		
//		
//		ArrayList<Integer> targets=new ArrayList<Integer>();
//		
//		for(int i=0;i<pills.length;i++)					//check which pills are available			
//			if(game.isPillStillAvailable(i))
//				targets.add(pills[i]);
//		
//		for(int i=0;i<powerPills.length;i++)			//check with power pills are available
//			if(game.isPowerPillStillAvailable(i))
//				targets.add(powerPills[i]);				
//		
//		int[] targetsArray=new int[targets.size()];		//convert from ArrayList to array
//		
//		for(int i=0;i<targetsArray.length;i++)
//			targetsArray[i]=targets.get(i);
//		
//		//return the next direction once the closest target has been identified
//		return game.getNextMoveTowardsTarget(current,game.getClosestNodeIndexFromNodeIndex(current,targetsArray,DM.PATH),DM.PATH);
	}
}























