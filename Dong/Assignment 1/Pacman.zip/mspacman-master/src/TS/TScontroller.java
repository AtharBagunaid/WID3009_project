
package TS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.EnumMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import pacman.controllers.Controller;
import pacman.controllers.examples.RandomGhosts;
import pacman.controllers.examples.RandomPacMan;
import pacman.controllers.examples.StarterGhosts;
import pacman.controllers.examples.StarterPacMan;
import pacman.game.Constants.DM;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.Game;



public class TScontroller extends Controller<MOVE> {

	
	public static final double C = 1.0f/Math.sqrt(2.0f);  //UCT函数的常量
	public static final int minghostdist = 9;
	public static final int maxhunt = 20;    
	public static final int treesize = 50;   //还行 可以说是测试次数 
	public static int depth = 0 ;
	public static Controller<EnumMap<GHOST,MOVE>> ghosts = new StarterGhosts();
	@Override
	public MOVE getMove(Game game, long timeDue) {
		
		
		for(GHOST ghost : GHOST.values()) {
			if(game.getGhostEdibleTime(ghost) > 0
                                &&game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(),
                                        game.getGhostCurrentNodeIndex(ghost)) < maxhunt) {
			return game.getNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),
                                game.getGhostCurrentNodeIndex(ghost), DM.PATH);
			}   //可吃且近
		}
		
		if(game.isJunction(game.getPacmanCurrentNodeIndex())) {  //交叉处的决策由MCTS完成
			depth = 0;
			return MCTSjuece(game);
		}
		return movetoward(game.getPacmanLastMoveMade() , game);
	}
	
	
	public MOVE movetoward(MOVE dir,Game state) {
	    MOVE[] possibleMoves = state.getPossibleMoves(state.getPacmanCurrentNodeIndex());
	    ArrayList<MOVE> moves = new ArrayList<MOVE>(Arrays.asList(possibleMoves));
	    
	    int current = state.getPacmanCurrentNodeIndex();        
            for(GHOST ghost : GHOST.values()) {
		if(state.getGhostEdibleTime(ghost)==0 
                   && state.getGhostLairTime(ghost)==0
                   &&state.getShortestPathDistance(current,state.getGhostCurrentNodeIndex(ghost)) < minghostdist) {
			return state.getNextMoveAwayFromTarget(current,state.getGhostCurrentNodeIndex(ghost), DM.PATH);
				}  //不可吃且过近
		}
	    
        if(moves.contains(dir)) return dir;
        moves.remove(state.getPacmanLastMoveMade().opposite());
        assert moves.size() == 1; //仅剩的道路
	return moves.get(0);
	}
	
	

	public MOVE MCTSjuece(Game game) {
		Node root = new Node(null,game,game.getPacmanCurrentNodeIndex());
		long start = new Date().getTime();
		
while (new Date().getTime() < start + 30 && depth <= treesize) {
			Node node = TreePolicy(root);
			if(node == null) return MOVE.DOWN;
			float reward = fenzong(node);
			backpropagation(node,reward);
		}Node bestChild = bestchild(root,0);  
		if(bestChild == null) {
			return new RandomPacMan().getMove(game,-1);
		}
		return bestChild.zou;
	}
	
	
	public Node TreePolicy(Node nd) {
		if(nd == null) {
			return nd;
		}
		while(!nd.terminalState()) {
			if(!nd.isFullyExpanded()) {
				return nd.Expand();
			}
			else {
				return nd = TreePolicy(bestchild(nd,C));
			}
		}
		return nd;
	}
	
	
	public float fenzong(Node nd) {
		Game state = nd.game.copy();
		int pills = state.getNumberOfActivePills();
		int lives = state.getPacmanNumberOfLivesRemaining();
		int livesAfter = state.getPacmanNumberOfLivesRemaining();
                Controller<MOVE> pacManController = new RandomPacMan();
		Controller<EnumMap<GHOST,MOVE>> ghostController = ghosts;
                if(nd == null) return 0;
                if(nd.dengji == 0.0f) {
			return 0;
		}
	while(!state.gameOver()) {
        	state.advanceGame(pacManController.getMove(state,System.currentTimeMillis()),
			ghostController.getMove(state,System.currentTimeMillis()));
        }if (livesAfter < lives) {
			return 0.0f;
		}
	if(state.getNumberOfActivePills() == 0) {
			return 1.0f;
		}return  1.0f -  ((float) state.getNumberOfActivePills() / ((float) pills));
	}
        private double UCTfunction(Node nd, double C) {
		double value = (float) ((nd.dengji / nd.visittime) 
                        + C* Math.sqrt(2*Math.log(nd.parent.visittime)/ nd.visittime));
		return value;            //随着访问次数的增加，加号后面的值越来越小，因此更加倾向于选择那些还没怎么被统计过的节点
                                        //避免碰巧的情况吧
	}
        private void backpropagation(Node currentNode, double reward) {
		while(currentNode != null) {
			currentNode.visittime ++;
			currentNode.dengji += reward;          //沿途更新各个父节点的统计信息
			currentNode = currentNode.parent;
                        
                        /*if is_root(node) return 
                        node.stats = update_stats(node, result) 
                        backpropagate(node.parent)   类似于递归里的回溯
*/
		}
	}
	
        public Node bestchild(Node node, double C) {    
		Node bestChild = null;
double bestValue = -1.0f;
		for(int i = 0 ; i < node.child.size(); i++) {
			if(UCTfunction(node.child.get(i), C) >= bestValue) {
				bestValue = UCTfunction(node.child.get(i),C);   //用uct函数来避免巧合达到最佳战绩 
				bestChild = (node.child.get(i));
			}
		}
		return bestChild;
	}

	

	

    private static class Node {

        public int junction = -1;
	public int visittime = 0;  //对某节点的探索次数
	
        public Node parent;
	public ArrayList<Node> child = new ArrayList<Node>();
	
        public MOVE zou;
	public double dengji;
	public ArrayList<MOVE> triedMoves = new ArrayList<MOVE>();
	public Game game;

	public Node(Node parent, Game game, int junction) {
		this.game = game;
		this.junction = junction;
		
		this.child.clear();
            this.parent = parent;
		this.zou = MOVE.UP;
		this.dengji = -1.0f;
		this.triedMoves.clear();
	}

	public Node Expand() {
		
		MOVE nextMove = untriedMove(game);
	if((nextMove != game.getPacmanLastMoveMade().opposite())) {
	 		Node expandedChild = getClosestJunction(nextMove);
	 		expandedChild.zou = nextMove;
			TScontroller.depth ++;
			this.child.add(expandedChild);
			expandedChild.parent = this;
			return expandedChild;
		}return this;
	}

	
	public Node getClosestJunction(MOVE dir) {
		
		Game state = game.copy();
		Controller<EnumMap<GHOST, MOVE>> ghostController = TScontroller.ghosts;
		
		int from = state.getPacmanCurrentNodeIndex();
		int current = from;
                int pillsBefore = state.getNumberOfActivePills();
		int ppillsBefore = state.getNumberOfActivePowerPills();
		int livesBefore = state.getPacmanNumberOfLivesRemaining();
		float transition_reward = 0.0f;
                MOVE currentPacmanDir = dir;
		while(!state.isJunction(current) || current == from){
	currentPacmanDir = path(state,currentPacmanDir);
			state.advanceGame(currentPacmanDir,
		    		ghostController.getMove(state,
		    		System.currentTimeMillis()));
			
			current = state.getPacmanCurrentNodeIndex();
		}
		
		int livesAfter = state.getPacmanNumberOfLivesRemaining();
		int pillsAfter = state.getNumberOfActivePills();
		int ppillsAfter = state.getNumberOfActivePowerPills();
		
		
		if (livesAfter < livesBefore) {
			transition_reward = 0.0f;
		}
		else if(ppillsAfter < ppillsBefore && averageDistance(state) > 100) {
			transition_reward = 0.0f;
		}
		else if(pillsAfter == pillsBefore) {
            transition_reward = 0.2f;
                }       
                else {
			transition_reward = 1.0f;
		}
		Node child = new Node(this,state,current);
		child.dengji = transition_reward;
		return child;
	}
	
    
	public MOVE path(Game state,MOVE direction) {
		MOVE[] possibleMoves = state.getPossibleMoves(state.getPacmanCurrentNodeIndex());
	    ArrayList<MOVE> moves = new ArrayList<MOVE>(Arrays.asList(possibleMoves));

        if(moves.contains(direction)) return direction;
        moves.remove(state.getPacmanLastMoveMade().opposite());
        assert moves.size() == 1; 
        return moves.get(0);
	}
        public boolean terminalState() {
		if (game.wasPacManEaten() || game.getActivePillsIndices().length == 0) {
			return true;}
		return false;
	}
        public static int averageDistance(Game state) {
		int sum = 0;
		for(GHOST ghost : GHOST.values())
		sum += state.getDistance(state.getPacmanCurrentNodeIndex(), 
                        state.getGhostCurrentNodeIndex(ghost), DM.PATH);
		        return sum/4;
	}

	
	public MOVE untriedMove(Game game) {
		ArrayList<MOVE> untriedMoves = new ArrayList<MOVE>();
		MOVE untriedMove = null;
		int current_node = game.getPacmanCurrentNodeIndex();
		List<MOVE> possibleMoves = Arrays.asList(game.getPossibleMoves(current_node));
	
		if (possibleMoves.contains(MOVE.UP) && !triedMoves.contains(MOVE.UP)) {
			untriedMoves.add(MOVE.UP);
		}
		if (possibleMoves.contains(MOVE.RIGHT) && !triedMoves.contains(MOVE.RIGHT)) {
			untriedMoves.add(MOVE.RIGHT);
		}
		if (possibleMoves.contains(MOVE.DOWN) && !triedMoves.contains(MOVE.DOWN)) {
			untriedMoves.add(MOVE.DOWN);
		} 
		if (possibleMoves.contains(MOVE.LEFT) && !triedMoves.contains(MOVE.LEFT)) {
			untriedMoves.add(MOVE.LEFT);
		}
		
		untriedMove = untriedMoves.get(new Random().nextInt(untriedMoves.size()));
		triedMoves.add(untriedMove);
		return untriedMove;
	}
	
	public boolean isFullyExpanded() {
		if ( child.size() <= 0) {
			return false;
		}
		
		int current_node = game.getPacmanCurrentNodeIndex();
		MOVE[] possibleMoves = game.getPossibleMoves(current_node);
		
		if(possibleMoves.length == triedMoves.size()) 
                    return true;
		if (possibleMoves.length != child.size()) {
			return false;
		} 
		else {
			return true;
		}
	}
	
	
    }
	
}
