Ms. Pac-Man: Maastricht
=============

This is the repository for the "maastricht" Ms. Pac-Man agent.
 
The agent won the CIG'12 edition of the Ms. Pac-Man vs Ghost Team competition: http://www.pacman-vs-ghosts.net/competitions/4

Moreover, the agent obtained a 2nd place at the WCCI'12 edition of the competition: http://www.pacman-vs-ghosts.net/competitions/3

If you would like to know more about the agent check out the paper describing the methods used: http://geneura.ugr.es/cig2012/papers/paper106.pdf

If you would like to improve or extend the agent please send me an e-mail at tom.pepels (at) maastrichtuniversity (dot) nl
