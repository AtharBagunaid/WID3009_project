# Joseph is the funniest to watch, he always does something cool
net.load(filename_weights='saved/joseph_weights.npy', filename_biases='saved/joseph_biases.npy')
game.start(display=True, neural_net=net)